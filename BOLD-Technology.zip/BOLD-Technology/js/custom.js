$(document).ready(function(){
    $(".firstName").keyup(function(){
        let fName = $(this).val();
        //console.log(fName);
        if(fName == ''){
            $(".firstLetter").text("f");
        }else{
            $(".firstLetter").text($(this).val().charAt(0));
        }
    });   
    
    $(".lastName").keyup(function(){
        let lName = $(this).val();
        //console.log(fName);
        if(lName == ''){
            $(".lastLetter").text("l");
        }else{
            $(".lastLetter").text($(this).val().charAt(0));
        }
    }); 

})